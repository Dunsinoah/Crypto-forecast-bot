#!/usr/bin/env python3
"""
crypto_telegram_report.py

Daily crypto GBM forecast -> PDF -> Telegram bot sender.
Designed to run in GitHub Actions or any Linux host.
Reads TG_BOT_TOKEN and TG_CHAT_ID from environment secrets.
"""

import os, math, requests, json
from datetime import datetime, timedelta
import numpy as np
import pandas as pd
from pycoingecko import CoinGeckoAPI
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import matplotlib.pyplot as plt

# Config (edit only if you know what you're doing)
COINS = {
    "bitcoin": "BTC",
    "ethereum": "ETH",
    "dogecoin": "DOGE",
    "binancecoin": "BNB",
    "solana": "SOL",
    "ripple": "XRP",
    "pepe": "PEPE",
    "sui": "SUI"
}

DAYS = 7
SIMS = 3000
MU = 0.0015  # daily drift
THRESHOLD_PCT = 1.0  # BUY if > +1%, SELL if < -1%

OUT_DIR = "out"
os.makedirs(OUT_DIR, exist_ok=True)

# Telegram credentials from environment (set as GitHub Secrets or env vars)
TG_BOT_TOKEN = os.getenv("TG_BOT_TOKEN")
TG_CHAT_ID = os.getenv("TG_CHAT_ID")

if not TG_BOT_TOKEN or not TG_CHAT_ID:
    raise SystemExit("TG_BOT_TOKEN and TG_CHAT_ID must be set as environment variables (GitHub Secrets).")

cg = CoinGeckoAPI()

def fetch_prices(coin_id, days=90):
    data = cg.get_coin_market_chart_by_id(id=coin_id, vs_currency='usd', days=days)
    prices = [p[1] for p in data.get("prices", [])]
    times = [pd.to_datetime(p[0], unit='ms') for p in data.get("prices", [])]
    if not prices:
        return pd.Series(dtype=float)
    s = pd.Series(data=prices, index=times)
    s = s.resample('D').last().ffill()
    return s

def run_gbm(S0, sigma, days=DAYS, sims=SIMS, mu=MU):
    sims_arr = np.zeros((sims, days+1))
    sims_arr[:,0] = S0
    for t in range(1, days+1):
        z = np.random.normal(size=sims)
        sims_arr[:,t] = sims_arr[:,t-1] * np.exp((mu - 0.5 * sigma**2) + sigma * z)
    median = np.median(sims_arr, axis=0)
    p5 = np.percentile(sims_arr, 5, axis=0)
    p95 = np.percentile(sims_arr, 95, axis=0)
    return median, p5, p95, sims_arr

def signal(current, median_value, threshold=THRESHOLD_PCT):
    if math.isnan(current) or math.isnan(median_value):
        return "N/A"
    ch = (median_value - current)/current*100.0
    if ch >= threshold: return "Buy"
    if ch <= -threshold: return "Sell"
    return "Hold"

def build_pdf(df, plots, pdf_path):
    c = canvas.Canvas(pdf_path, pagesize=letter)
    c.setFont("Helvetica-Bold", 14)
    c.drawString(120, 750, "Crypto Daily Forecast & Signals")
    c.setFont("Helvetica", 10)
    c.drawString(120, 735, f"Generated (UTC): {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')}")
    c.line(40, 730, 560, 730)
    y = 710
    c.setFont("Helvetica-Bold", 10)
    headers = ["Coin","Current","D1_Med","D1_Sig","D2_Med","D2_Sig","D7_Med"]
    xs = [40,110,190,270,330,410,480]
    for i,h in enumerate(headers):
        c.drawString(xs[i], y, h)
    y -= 14
    c.setFont("Helvetica", 9)
    for idx, row in df.iterrows():
        if y < 120:
            c.showPage()
            y = 740
        c.drawString(xs[0], y, str(idx))
        c.drawRightString(xs[1]+40, y, f"{row['Current']:.6g}" if not pd.isna(row['Current']) else "N/A")
        c.drawRightString(xs[2]+40, y, f"{row['D1_median']:.6g}" if not pd.isna(row['D1_median']) else "N/A")
        c.drawString(xs[3], y, row.get('D1_Signal','N/A'))
        c.drawRightString(xs[4]+40, y, f"{row['D2_median']:.6g}" if not pd.isna(row['D2_median']) else "N/A")
        c.drawString(xs[5], y, row.get('D2_Signal','N/A'))
        c.drawRightString(xs[6]+60, y, f"{row['D7_median']:.6g}" if not pd.isna(row['D7_median']) else "N/A")
        y -= 12
    # Add plots
    for coin, path in plots.items():
        c.showPage()
        c.setFont("Helvetica-Bold", 12)
        c.drawCentredString(300, 760, f"{coin} — 7-day forecast")
        try:
            c.drawImage(path, 40, 120, width=520, height=420)
        except Exception:
            c.setFont("Helvetica", 10)
            c.drawString(40, 700, "Chart not available.")
    c.save()
    return pdf_path

def send_text(text):
    url = f"https://api.telegram.org/bot{TG_BOT_TOKEN}/sendMessage"
    payload = {"chat_id": TG_CHAT_ID, "text": text, "parse_mode": "Markdown"}
    r = requests.post(url, data=payload, timeout=20)
    return r.ok, r.text

def send_file(path, caption="Daily crypto report"):
    url = f"https://api.telegram.org/bot{TG_BOT_TOKEN}/sendDocument"
    with open(path, "rb") as f:
        files = {"document": f}
        data = {"chat_id": TG_CHAT_ID, "caption": caption}
        r = requests.post(url, data=data, files=files, timeout=60)
    return r.ok, r.text

def main():
    rows = []
    plots = {}
    for coin_id, ticker in COINS.items():
        series = fetch_prices(coin_id, days=90)
        if series.empty:
            rows.append((ticker, float('nan'), float('nan'), float('nan'), "NoData","NoData", float('nan')))
            continue
        current = float(series.iloc[-1])
        logr = np.log(series/series.shift(1)).dropna()
        sigma = float(logr.std()) if len(logr) > 5 else 0.08
        median, p5, p95, sims = run_gbm(current, sigma)
        d1_med = median[1]
        d2_med = median[2]
        d7_med = median[-1]
        d1_sig = signal(current, d1_med)
        d2_sig = signal(current, d2_med)
        rows.append((ticker, current, d1_med, d2_med, d7_med, d1_sig, d2_sig))
        # plot
        import matplotlib.pyplot as plt
        dates = [(datetime.utcnow().date() + timedelta(days=i)).isoformat() for i in range(DAYS+1)]
        plt.figure(figsize=(8,3.5))
        plt.plot(dates, median, label='Median')
        plt.fill_between(dates, p5, p95, alpha=0.2)
        plt.scatter([dates[0]], [current], label='Current', zorder=3)
        plt.title(f"{ticker} 7-day GBM forecast")
        plt.xticks(rotation=30)
        plt.tight_layout()
        ppath = os.path.join(OUT_DIR, f"{ticker}_7d.png")
        plt.savefig(ppath)
        plt.close()
        plots[ticker] = ppath
    cols = ["Coin","Current","D1_median","D2_median","D7_median","D1_Signal","D2_Signal"]
    df = pd.DataFrame(rows, columns=cols).set_index("Coin")
    # build message & top pick
    top_pick = None
    best_move = 0
    lines = [f"*Crypto Signals — {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}*"]
    for idx, r in df.iterrows():
        cur = "N/A" if math.isnan(r['Current']) else f"{r['Current']:.6g}"
        lines.append(f"{idx}: {cur} → D1 {r['D1_median']:.6g} ({r['D1_Signal']}) | D2 {r['D2_median']:.6g} ({r['D2_Signal']})")
        if r['D1_Signal'] in ('Buy','Sell') and not math.isnan(r['Current']):
            move = abs((r['D1_median'] - r['Current'])/r['Current'])*100.0
            if move > best_move:
                best_move = move
                top_pick = (idx, r['D1_Signal'], round(move,2))
    if top_pick:
        lines.insert(1, f"*Top Action:* {top_pick[0]} — {top_pick[1]} (est {top_pick[2]}%)\n")
    message = "\n".join(lines)
    pdf_path = os.path.join(OUT_DIR, f"crypto_report_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.pdf")
    build_pdf(df, plots, pdf_path)
    # send
    ok_text, resp_text = send_text(message)
    ok_doc, resp_doc = send_file(pdf_path, caption="Daily crypto forecast (PDF)")
    # save csv
    df.to_csv(os.path.join(OUT_DIR, "crypto_summary.csv"))
    out = {"text_sent": ok_text, "doc_sent": ok_doc, "pdf": pdf_path}
    print(json.dumps(out))
    return out

if __name__ == "__main__":
    main()
