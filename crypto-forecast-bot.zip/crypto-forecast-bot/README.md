
# Crypto Forecast Bot (GitHub Actions)

This repository contains a Python bot that fetches live crypto prices from CoinGecko,
runs a short-term GBM-based forecast, generates Buy/Sell/Hold signals for Day-1 & Day-2,
creates a PDF report with charts, and sends both a summary and the PDF to a Telegram chat.

## Features
- Coins: BTC, ETH, DOGE, BNB, SOL, XRP, PEPE, SUI
- Forecast horizon: 7 days (2-day actionable signals)
- Signal rule: BUY if median forecast >= +1%, SELL if <= -1%, else HOLD
- Runs via GitHub Actions (scheduled daily) or manual trigger

## Setup (quick)
1. Create a GitHub repository and upload these files.
2. Add two repository secrets:
   - `TG_BOT_TOKEN` — your Telegram bot token
   - `TG_CHAT_ID` — your Telegram chat id
3. The workflow is scheduled to run daily at 6 AM UTC (7 AM Lagos).

## Local test
You can run locally for testing (requires Python 3.8+):
```
pip install pycoingecko pandas numpy reportlab requests matplotlib
python crypto_telegram_report.py
```

## Security
- Do NOT commit your bot token to the repo. Use GitHub Secrets.
- Keep the repo private if you prefer privacy.
